package com.example.XWin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XWinApplication {

	public static void main(String[] args) {
		SpringApplication.run(XWinApplication.class, args);
	}

}
